<!DOCTYPE html>
<html>
<head>
	<title>Restful Web-servive</title>
</head>
<body>
	 <form name="LoginForm" method="POST" action="Webservice.php">
		<center>
		<h1>Login Form</h1>
		<p>Enter your name</p>
		<input type="text" name="first" placeholder="enter name" id="name" required="" />
		<p >Enter Roll_Number</p>
		<input type="text" name="roll" placeholder="eg:16SW44"  required="" />
		<br><input type="Submit" name="btn" placeholder="Submit" />
	    <p><input type="checkbox" name="chk"/>Remember me</p>
	    <a href="MAIL TO:Kashmalakhan544@yahoo.com">Forgot password?</a>
	</center>
	</form>
</body>
</html>
